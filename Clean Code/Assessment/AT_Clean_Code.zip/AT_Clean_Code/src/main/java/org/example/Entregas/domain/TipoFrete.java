package org.example.Entregas.domain;

public enum TipoFrete {
    EXP, PAD, ECO
}

