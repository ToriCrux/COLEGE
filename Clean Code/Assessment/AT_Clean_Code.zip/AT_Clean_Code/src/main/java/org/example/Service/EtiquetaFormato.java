package org.example.Service;
import org.example.Entregas.domain.Entrega;

public interface EtiquetaFormato {
    String formatar(Entrega entrega, double valorFrete);
}
