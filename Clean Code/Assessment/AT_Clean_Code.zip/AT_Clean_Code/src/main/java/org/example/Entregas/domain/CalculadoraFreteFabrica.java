package org.example.Entregas.domain;

import java.util.HashMap;
import java.util.Map;

public class CalculadoraFreteFabrica{

    private static final Map<TipoFrete, CalculadoraFrete> mapa = new HashMap<>();

    static {
        mapa.put(TipoFrete.EXP, new FreteExpresso());
        mapa.put(TipoFrete.PAD, new FretePadrao());
        mapa.put(TipoFrete.ECO, new FreteEconomico());
    }

    public static CalculadoraFrete obterCalculadora(TipoFrete tipoFrete) {
        CalculadoraFrete calculadora = mapa.get(tipoFrete);
        if (calculadora == null) {
            throw new ValidacaoException("Tipo de frete não suportado: " + tipoFrete);
        }
        return calculadora;
    }

    public static void registrar(TipoFrete tipoFrete, CalculadoraFrete calculadora) {
        mapa.put(tipoFrete, calculadora);
    }
}
