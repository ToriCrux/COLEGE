package org.example.Entregas.domain;

public interface CalculadoraFrete {
    double calcular(Entrega entrega);
}

