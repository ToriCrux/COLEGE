package org.example.Entregas.domain;

public class FreteEconomico implements CalculadoraFrete {
    @Override
    public double calcular(Entrega entrega) {
        return entrega.getPeso() * 1.1 - 5;
    }
}

