package org.example.Service;

import org.example.Entregas.domain.CalculadoraFrete;
import org.example.Entregas.domain.Entrega;
import org.example.Entregas.domain.ValidacaoException;

public class EtiquetaService {

    private final EtiquetaFormato formatter;

    public EtiquetaService(EtiquetaFormato formatter) {
        if (formatter == null)
            throw new ValidacaoException("Formatter não pode ser nulo.");
        this.formatter = formatter;
    }

    public String gerarEtiqueta(Entrega entrega, CalculadoraFrete calculadora) {
        if (calculadora == null)
            throw new ValidacaoException("Calculadora de frete não pode ser nula.");
        double valorFrete = calculadora.calcular(entrega);
        return formatter.formatar(entrega, valorFrete);
    }

    public String gerarResumo(Entrega entrega, CalculadoraFrete calculadora) {
        if (calculadora == null)
            throw new ValidacaoException("Calculadora de frete não pode ser nula.");
        double valorFrete = calculadora.calcular(entrega);
        return "Pedido para " + entrega.getDestinatario() +
                " com frete tipo " + entrega.getTipoFrete() +
                " no valor de R$" + String.format("%.2f", valorFrete);
    }
}
