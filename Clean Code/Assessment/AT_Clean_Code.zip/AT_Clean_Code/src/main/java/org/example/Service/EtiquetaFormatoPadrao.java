package org.example.Service;

import org.example.Entregas.domain.Entrega;

public class EtiquetaFormatoPadrao implements EtiquetaFormato {

    @Override
    public String formatar(Entrega entrega, double valorFrete) {
        return "Destinatário: " + entrega.getDestinatario() +
                "\nEndereço: " + entrega.getEndereco() +
                "\nValor do Frete: R$" + String.format("%.2f", valorFrete);
    }
}

