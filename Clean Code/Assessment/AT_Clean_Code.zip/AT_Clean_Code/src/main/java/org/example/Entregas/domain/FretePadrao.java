package org.example.Entregas.domain;

public class FretePadrao implements CalculadoraFrete {
    @Override
    public double calcular(Entrega entrega) {
        return entrega.getPeso() * 1.2;
    }
}
