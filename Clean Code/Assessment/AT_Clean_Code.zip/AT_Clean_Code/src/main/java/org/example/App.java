package org.example;

import org.example.Entregas.domain.*;
import org.example.Service.*;

public class App {
    public static void main(String[] args) {
        try {
            Entrega entrega = new Entrega("Rua das Rosas, 57", 9.0, TipoFrete.PAD, "Victória Cruz");

            CalculadoraFrete frete = CalculadoraFreteFabrica.obterCalculadora(entrega.getTipoFrete());
            EtiquetaFormato formatter = new EtiquetaFormatoPadrao();

            EtiquetaService etiquetaService = new EtiquetaService(formatter);

            System.out.println(etiquetaService.gerarEtiqueta(entrega, frete));
            System.out.println(etiquetaService.gerarResumo(entrega, frete));
        } catch (ValidacaoException e) {
            System.err.println("Erro: " + e.getMessage());
        }
    }
}
