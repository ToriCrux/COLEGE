package org.example;
import org.example.controller.UsuarioController;

public class App {
    public static void main(String[] args) {
        UsuarioController usuarioController = new UsuarioController();
        usuarioController.respostasRequisicoes();
    }
}
