/*
 * Avaliação de Design
 *
 * A estrutura atual visa facilitar a adição de novos tipos de item, seguindo o Princípio Aberto-Fechado (OCP).
 * Ou seja, o sistema está aberto para extensão de itens (através de novas implementações de ItemUpdater),
 * mas fechado para modificação, já que não é necessário alterar o código existente para suportar um novo item.
 *
 * A implementação das classes que estendem ItemUpdater respeita o Princípio da Responsabilidade Única (SRP),
 * pois cada classe é responsável apenas pelas regras de atualização de um tipo específico de item.
 * Isso torna o código mais legível, testável e de fácil manutenção.
 *
 * E o Princípio de Substituição de Liskov (LSP), é respeitado já que todas as implementações da interface ItemUpdater
 * podem substituir a referência de tipo base sem alterar o comportamento esperado do programa.
 * Não há pré-condições ou efeitos colaterais adicionais que quebrem a substituição.
 * Portanto, não foram identificadas violações ao LSP na hierarquia criada.
 */

package com.gildedrose;

import java.util.HashMap;
import java.util.Map;

class GildedRose {
    Item[] items;
    Map<String, ItemUpdater> updaterMap;

    public GildedRose(Item[] items) {
        this.items = items;
        updaterMap = new HashMap<>();
        updaterMap.put("Aged Brie", new AgedBrieUpdater());
        updaterMap.put("Backstage passes to a TAFKAL80ETC concert", new BackstagePassUpdater());
        updaterMap.put("Sulfuras, Hand of Ragnaros", new SulfurasUpdater());
        updaterMap.put("Conjured", new ConjuredItemUpdater()); // ← Linha adicionada aqui
    }

    public void updateQuality() {
        for (Item item : items) {
            ItemUpdater updater = updaterMap.getOrDefault(item.name, new DefaultUpdater());
            updater.update(item);
        }
    }
}
