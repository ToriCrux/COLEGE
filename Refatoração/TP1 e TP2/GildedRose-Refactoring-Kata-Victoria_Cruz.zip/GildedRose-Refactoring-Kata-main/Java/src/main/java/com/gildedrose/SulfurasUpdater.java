package com.gildedrose;

public class SulfurasUpdater implements ItemUpdater {
    @Override
    public void update(Item item) {
        // Sulfuras não muda qualidade nem sellIn
    }
}
