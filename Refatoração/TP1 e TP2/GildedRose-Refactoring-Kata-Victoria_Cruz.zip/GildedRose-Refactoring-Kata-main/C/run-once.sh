make
./GildedRoseTextTests
