package CalculoIMC;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import java.util.Scanner;

class CalculoIMCServiceTest {

    @Test
    void testProgramaIMCComMock() {
        // Criando um mock para Scanner
        Scanner scannerMock = mock(Scanner.class);

        // Simulando entrada do usuário
        when(scannerMock.nextLine()).thenReturn("70", "1.75");

        // Chamando o método com o mock
        double peso = Double.parseDouble(scannerMock.nextLine());
        double altura = Double.parseDouble(scannerMock.nextLine());

        double imc = CalculoIMC.calcularPeso(peso, altura);
        String classificacao = CalculoIMC.classificarIMC(imc);

        // Validando os valores calculados
        assert imc > 0;
        assert classificacao.equals("Saudável"); // IMC de 70kg e 1.75m ≈ 22.86
    }
}
