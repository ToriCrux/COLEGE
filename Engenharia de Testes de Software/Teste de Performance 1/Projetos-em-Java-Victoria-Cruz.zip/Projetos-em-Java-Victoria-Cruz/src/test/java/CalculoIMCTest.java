package CalculoIMC;

import CalculoIMC.CalculoIMC;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CalculoIMCTest {

    @Test
    void testValoresValidos() {
        assertEquals("Magreza grave", CalculoIMC.classificarIMC(15.79));
        assertEquals("Magreza moderada", CalculoIMC.classificarIMC(16.70));
        assertEquals("Magreza leve", CalculoIMC.classificarIMC(17.31));
        assertEquals("Saudável", CalculoIMC.classificarIMC(23.25));
        assertEquals("Sobrepeso", CalculoIMC.classificarIMC(28.39));
        assertEquals("Obesidade Grau I", CalculoIMC.classificarIMC(32.10));
        assertEquals("Obesidade Grau II", CalculoIMC.classificarIMC(36.50));
        assertEquals("Obesidade Grau III", CalculoIMC.classificarIMC(41.00));
    }

    @Test
    void testLimitesExatos() {
        String resultado = CalculoIMC.classificarIMC(16.0);
        if (!resultado.equals("Magreza grave")) {
            System.out.println("Erro: O IMC 16.0 deveria ser 'Magreza grave', mas retornou: " + resultado);
        }

        resultado = CalculoIMC.classificarIMC(17.0);
        if (!resultado.equals("Magreza moderada")) {
            System.out.println("Erro: O IMC 17.0 deveria ser 'Magreza moderada', mas retornou: " + resultado);
        }

        resultado = CalculoIMC.classificarIMC(18.5);
        if (!resultado.equals("Magreza leve")) {
            System.out.println("Erro: O IMC 18.5 deveria ser 'Magreza leve', mas retornou: " + resultado);
        }

        resultado = CalculoIMC.classificarIMC(25.0);
        if (!resultado.equals("Sobrepeso")) {
            System.out.println("Erro: O IMC 25.0 deveria ser 'Sobrepeso', mas retornou: " + resultado);
        }

        resultado = CalculoIMC.classificarIMC(30.0);
        if (!resultado.equals("Obesidade Grau I")) {
            System.out.println("Erro: O IMC 30.0 deveria ser 'Obesidade Grau I', mas retornou: " + resultado);
        }

        resultado = CalculoIMC.classificarIMC(35.0);
        if (!resultado.equals("Obesidade Grau II")) {
            System.out.println("Erro: O IMC 35.0 deveria ser 'Obesidade Grau II', mas retornou: " + resultado);
        }

        resultado = CalculoIMC.classificarIMC(40.0);
        if (!resultado.equals("Obesidade Grau III")) {
            System.out.println("Erro: O IMC 40.0 deveria ser 'Obesidade Grau III', mas retornou: " + resultado);
        }
    }

    @Test
    void testCalculoPeso() {
        assertEquals(22.86, CalculoIMC.calcularPeso(70, 1.75), 0.1);
        assertEquals(27.78, CalculoIMC.calcularPeso(80, 1.70), 0.1);
        assertEquals(35.85, CalculoIMC.calcularPeso(100, 1.67), 0.1);
    }

    @Test
    void testValoresInvalidos() {
        double resultadoNegativo = CalculoIMC.calcularPeso(-70, 1.75);
        if (resultadoNegativo > 0) {
            System.out.println("Erro: O cálculo de IMC aceitou um peso negativo! Código precisa ser refatorado.");
        }

        double resultadoAlturaZero = CalculoIMC.calcularPeso(70, 0);
        if (!Double.isInfinite(resultadoAlturaZero) && resultadoAlturaZero > 0) {
            System.out.println("Erro: O cálculo de IMC aceitou altura zero! Código precisa ser refatorado.");
        }

        double resultadoPesoZero = CalculoIMC.calcularPeso(0, 1.75);
        if (resultadoPesoZero > 0) {
            System.out.println("Erro: O cálculo de IMC aceitou peso zero! Código precisa ser refatorado.");
        }
    }
}
