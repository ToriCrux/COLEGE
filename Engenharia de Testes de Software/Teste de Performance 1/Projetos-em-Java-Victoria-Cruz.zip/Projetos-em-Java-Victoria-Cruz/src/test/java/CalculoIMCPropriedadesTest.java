package CalculoIMC;

import net.jqwik.api.*;
import org.apache.commons.lang3.tuple.Pair;
import static org.assertj.core.api.Assertions.assertThat;

class CalculoIMCPropriedadesTest {

    @Property
    void testIMCComCasosEspecíficos(@ForAll("casosEspecificos") Pair<Double, Double> valores) {
        double peso = valores.getLeft();
        double altura = valores.getRight();
        double imc = CalculoIMC.calcularPeso(peso, altura);

        // O IMC de um adulto geralmente varia entre 10 e 50
        assertThat(imc).isBetween(10.0, 50.0);
    }

    @Property
    void testIMCValoresLimite(@ForAll("valoresLimite") Pair<Double, Double> valores) {
        double peso = valores.getLeft();
        double altura = valores.getRight();
        double imc = CalculoIMC.calcularPeso(peso, altura);

        // Garantir que o IMC não seja negativo ou infinito
        assertThat(imc).isGreaterThan(0).isLessThan(50);
        assertThat(Double.isInfinite(imc)).isFalse();
    }

    @Property
    void imcNuncaDeveSerNegativo(@ForAll("valoresValidos") double peso,
                                 @ForAll("valoresValidos") double altura) {
        double imc = CalculoIMC.calcularPeso(peso, altura);
        assertThat(imc).isGreaterThanOrEqualTo(0);
    }

    @Property
    void testImcValoresExtremos(@ForAll("pesosExtremos") double peso,
                                @ForAll("alturasExtremas") double altura) {
        double imc = CalculoIMC.calcularPeso(peso, altura);

        // Restrição para IMC não ser NaN e infinito
        assertThat(imc).isGreaterThanOrEqualTo(0).isNotNaN();
        assertThat(Double.isInfinite(imc)).isFalse();
    }

    // 🔥 Novo teste sem restrições de entrada
    @Property
    void testIMCComValoresAleatorios(@ForAll double peso, @ForAll double altura) {
        double imc = CalculoIMC.calcularPeso(peso, altura);

        // Verifica se o IMC não é negativo e não gera erros
        assertThat(imc).isGreaterThanOrEqualTo(0).isNotNaN();
    }

    @Provide
    Arbitrary<Pair<Double, Double>> casosEspecificos() {
        return Arbitraries.of(
                Pair.of(50.0, 1.60),
                Pair.of(70.0, 1.75),
                Pair.of(100.0, 1.90)
        );
    }

    @Provide
    Arbitrary<Pair<Double, Double>> valoresLimite() {
        return Arbitraries.of(
                Pair.of(30.0, 1.50),
                Pair.of(150.0, 1.90),
                Pair.of(1.0, 0.5)
        );
    }

    @Provide
    Arbitrary<Double> valoresValidos() {
        return Arbitraries.doubles().between(1.0, 300.0);
    }

    @Provide
    Arbitrary<Double> pesosExtremos() {
        return Arbitraries.of(1.0, 40.0, 150.0, 400.0);
    }

    @Provide
    Arbitrary<Double> alturasExtremas() {
        return Arbitraries.of(0.1, 0.5, 3.0, 5.0);
    }
}
