import net.jqwik.api.*;

class CustomGenerators {
    @Provide
    Arbitrary<Double> alturasExtremas() {
        return Arbitraries.of(0.1, 0.5, 3.0, 5.0);  // Alturas improváveis
    }

    @Provide
    Arbitrary<Double> pesosExtremos() {
        return Arbitraries.of(1.0, 40.0, 150.0, 400.0);  // Pesos extremos
    }
}
